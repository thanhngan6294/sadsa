#include <QApplication>
#include <QItemSelection>
#include <QItemSelectionModel>
#include <QTableView>
#include <delegate.h>
#include "model.h"
#include <QHeaderView>
#include <treeitem.h>
#include <treemodel.h>
#include <QHBoxLayout>
#include <QWidget>
#include <QTreeView>
#include <QGridLayout>
#include <QSplitter>
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QSplitter splitter;
    TableModel *model1 = new TableModel(8, 4, &app);
    QTableView *table = new QTableView(0);

    table->setModel(model1);
    model1->setHeaderData(1, Qt::Horizontal, QObject::tr("ID"));
    model1->setHeaderData(2, Qt::Horizontal, QObject::tr("ID"));
    model1->setHeaderData(3, Qt::Horizontal, QObject::tr("ID"));
    model1->setHeaderData(4, Qt::Horizontal, QObject::tr("ID"));

    QTreeView *view = new QTreeView;
    QFile file(":/Can.dbc");
    file.open(QIODevice::ReadOnly);
    TreeModel model(file.readAll());
    file.close();

    view->setModel(&model);
    splitter.addWidget(view);
    splitter.addWidget(table);
    ComboBoxDeleGate delegate;
    table->setItemDelegate(&delegate);
    table->horizontalHeader()->setStretchLastSection(true);
    table->verticalHeader()->setVisible(false);
    splitter.show();
    splitter.setWindowIcon(QPixmap(":/images.jpg"));
    return app.exec();
}
